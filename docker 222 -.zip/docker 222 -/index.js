import express from 'express';
import mongoose from 'mongoose';

const Animal = mongoose.model('Animal', new mongoose.Schema({
  tipo: String,
  estado: String,
}));

const app = express();
app.use(express.static('public')); // Sirve archivos estáticos de la carpeta public
app.use(express.urlencoded({ extended: true })); // Procesa datos de formularios

// Conexión a MongoDB
mongoose.connect('mongodb://saul:123@Monguito:27017/miapp?authSource=admin')
  .then(() => console.log('Conectado a MongoDB'))
  .catch((error) => console.error('Error de conexión a MongoDB:', error));

// Ruta para mostrar la lista de animales
app.get('/', async (_req, res) => {
  const animales = await Animal.find();
  const animalesHtml = animales.map(animal => `<li>${animal.tipo} - ${animal.estado}</li>`).join('');
  
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Lista de Animales</title>
      <link rel="stylesheet" href="/styles.css">
    </head>
    <body>
      <h1>Lista de Animales</h1>
      <ul>${animalesHtml}</ul>
      <a href="/nuevo" class="agregar-btn">Agregar nuevo animal</a>
    </body>
    </html>
  `);
});

// Ruta para mostrar el formulario de ingreso de nuevos animales
app.get('/nuevo', (_req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Agregar Animal</title>
      <link rel="stylesheet" href="/styles.css">
    </head>
    <body>
      <h1>Agregar Nuevo Animal</h1>
      <form action="/crear" method="POST" class="formulario">
        <label for="tipo">Tipo de Animal:</label>
        <input type="text" id="tipo" name="tipo" required>
        
        <label for="estado">Estado del Animal:</label>
        <input type="text" id="estado" name="estado" required>
        
        <button type="submit">Guardar Animal</button>
      </form>
      <a href="/" class="volver">Volver a la lista</a>
    </body>
    </html>
  `);
});

// Ruta POST para crear un nuevo animal a partir del formulario
app.post('/crear', async (req, res) => {
  const { tipo, estado } = req.body;
  await Animal.create({ tipo, estado });
  res.redirect('/');
});

// Iniciar el servidor
app.listen(3000, () => console.log('Servidor escuchando en el puerto 3000'));
